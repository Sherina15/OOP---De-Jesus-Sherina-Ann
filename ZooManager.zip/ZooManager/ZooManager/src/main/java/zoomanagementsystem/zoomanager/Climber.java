package zoomanagementsystem.zoomanager;

public interface Climber 
{
    void climb();
}
