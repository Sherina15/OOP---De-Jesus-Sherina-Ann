package zoomanagementsystem.zoomanager;

public class Mammal extends Animal implements Walking, Swimmable
{
    
    String furColor;
    
    public Mammal(String types, String name, int age,String gender, double weight,String furColor, String habitat)
    {
        super (types,name,age,gender,weight,habitat);
        this.furColor = furColor;
        
    }
    @Override
    void makeSound() 
    {
      System.out.println ( types + " can make sound ");  
    }

    @Override
    void sleep() 
    {
      System.out.println ( types + " is sleeping ");    
    }

    @Override
    void eat() 
    {
     System.out.println ( types + " is eating ");     
    }

    @Override
    public void walk() 
    {
      System.out.println ( types + " can Walk");
    }

    @Override
    public void swim() 
    {
       System.out.println ( types + " can Swim"); 
    }   

}