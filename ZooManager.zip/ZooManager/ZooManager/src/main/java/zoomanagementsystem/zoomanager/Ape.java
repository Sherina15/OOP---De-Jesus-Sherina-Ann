package zoomanagementsystem.zoomanager;

public class Ape extends Mammal implements Climber{

    public Ape(String types, String name, int age, String gender, double weight, String furColor, String habitat) 
    {
        super(types, name, age, gender, weight, furColor, habitat);
    }
    
    @Override
    void makeSound()
    {
        System.out.println("Ape gibber");
    }
    
    @Override
    void sleep()
    {
        System.out.println ( "Ape curl up to sleep");
    }
    
    @Override
    void eat()
    {
        System.out.println("Ape eat fruit");   
    }
    
    
    @Override
    public void climb() 
    {
       System.out.println("Ape can Climb");
    }
    
}
