package zoomanagementsystem.zoomanager;

public class Monkey extends Primate implements Climber 
{
    
    public Monkey(String types, String name, int age, String gender, double weight, String furColor, String habitat) 
    {
        super(types, name, age, gender, weight, furColor, habitat);
    }
    
    @Override
    void makeSound()
    {
        System.out.println("Monkey make sound ooh-ooh ah-ah");  
    }
    
    @Override
    void sleep()
    {
        System.out.println("Monkey sleep around 13 hours a day");
    }
    
    @Override
    void eat()
    {
        System.out.println ("Monkey eat banana");  
    }
    
    @Override
    public void climb()
    {
        System.out.println("Monkey climbing at the tree");
    }
    
}
