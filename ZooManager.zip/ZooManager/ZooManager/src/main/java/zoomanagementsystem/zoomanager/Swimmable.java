package zoomanagementsystem.zoomanager;

public interface Swimmable 
{
    void swim();
}
